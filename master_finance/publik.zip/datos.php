<?php 



echo $_POST['username'];
echo $_POST['name'];
echo $_POST['lastname'];
echo "<h1>ANDRES</h1>";





?>
<h1>lo demas</h1>